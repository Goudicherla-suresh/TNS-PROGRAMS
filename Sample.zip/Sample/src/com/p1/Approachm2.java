package com.p1;

public class Approachm2 {
	int a=2;
   static int b=5;
	
	int Tns() {
		return 1;
		
	}
	 static void display() {
		 System.out.println(3);
		 
	 }
    class B{
    	 
	public static void main(String[] args) {
	 Approachm2 a1=new Approachm2() ;
	 System.out.println(a1.a);
	 System.out.println(a1.Tns());
	 
	 System.out.println(Approachm2.b);
	 Approachm2.display();
	}
	}

}
