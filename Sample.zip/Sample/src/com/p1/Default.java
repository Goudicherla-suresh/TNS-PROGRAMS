package com.p1;

public  class Default {
	
	int a=10;
	static int b=12;

	 
	public static void main(String[] args) {
		Default obj=new Default();
	System.out.println(obj.a);
	System.out.println(Default.b);
	}
     
      	
	

}
