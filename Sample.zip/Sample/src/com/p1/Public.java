package com.p1;

public class Public{
	
	public void display() {
		System.out.println("well come TNS");
	}
	}


	