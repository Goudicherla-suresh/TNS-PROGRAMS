package com.p1;

public class Approachm1 {
		int a=10;
		static int b=20;
    int Tns() {
	   return 1;
	   
   }
   static void display1() {
	   System.out.println(1);
   }
public static void main(String args[]) {
	 Approachm1 a1=new Approachm1();
	 System.out.println(a1.a);
	 
	 System.out.println(a1.Tns());
	 System.out.println(Approachm1.b);
	 Approachm1.display1();
	 
}
}
