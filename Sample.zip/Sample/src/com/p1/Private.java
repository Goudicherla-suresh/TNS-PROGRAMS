package com.p1;

public class Private {
		public void display() {
			System.out.println("This is Private Class");
		}

}
class B{
	public static void main(String[] args) {
		Private obj=new Private();
		obj.display();
	}
}
