package com.p1;

public class Approach1 {
	int a=1;
 static	int b=2;
	

	public static void main(String[] args) {
		int c=30;
		
		System.out.println(c);
		Approach1 a1=new Approach1();
		
		System.out.println(a1.a);
		System.out.println(Approach1.b);
		

	}

}
