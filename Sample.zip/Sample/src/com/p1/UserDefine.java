package com.p1;

public class UserDefine {
public	int a=0;
public	static int b=20;
public	int TNS() {
	return(1);
	}
	
public static void  display() {
		System.out.println();
	

		}
		
	}
	
