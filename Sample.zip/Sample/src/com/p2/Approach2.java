package com.p2;

public class Approach2 {
	
	int a=10;
	static int b=20;

class D{
	
	
	public static void main(String[] args) {
		Approach2 a1=new Approach2();
		System.out.println(a1.a);
		System.out.println(Approach2.b);
		

	}

}


}




