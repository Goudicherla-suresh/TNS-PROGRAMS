package com.p2;
import com.p1.*;
public class User2 {


		public static void main(String[] args) {
			UserDefine obj=new UserDefine();
			System.out.println(obj.a);
			System.out.println(obj.TNS());
		   System.out.println(UserDefine.b);
			UserDefine.display();

}
}