package com.p2;

public class Publicimp {

}
