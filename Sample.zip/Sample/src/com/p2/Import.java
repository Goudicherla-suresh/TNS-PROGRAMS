package com.p2;
 import com.p1.*;
public class Import {
 public static void main (String[] args) {
	 
	 Public A=new Public();
	 A.display();	
 }
	

}
